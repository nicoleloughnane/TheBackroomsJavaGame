package theBackroomsV1;

public class Tool implements Item {

	/*
	Create 2 instance variables:  name, description
	*/
	private String name;
	private String description;
	
	/**
	 * Tool class constructor
	 * it builds a key with a name, description
	 * @param: a string to set the name of a Tool object
	 * @param: a string to set the description of a Tool object
	 */
	public Tool(String n, String d) {
		name = n;
		description = d;
	}
	
	/**
	 * Mutator method called "setName"
	 * 	This method is used to change the name of a Tool object
	 * 	@param: a String to update the name of a Tool object
	*/
	public void setName(String n) {
		name = n;
	}
	
	/**
	 * 	Mutator method called "setDescription"
	 * 	This method is used to change the description of a Tool object
	 * 	@param: a String to update the description of a Tool object
	*/
	public void setDescription(String d) {
		 description = d;
	 }
	/**
	 * Accessor method called "getName"
	 * This method is used to retrieve the name of a Tool object
	 * @return: a String that is the name of a Tool object
	*/
	public String getName() {
		return name;
	}
	/**
	 * Accessor method called "getDescription"
	 * This method is used to retrieve the description of a Tool object
	 * @return: a String that is the description of a Tool object
	*/	
	public String getDescription() {
		return description;
	}
	
	/**
	 * Accessor method called "toString", overwrites the default toString method
	 * This method is used to retrieve all of the characteristics of a Tool object
	 * @return: a String that is all of the characteristics of a Tool object
	*/	
	public String toString() {
		return "\n" + name + ":\nDescription: " + description;
	}

}
