package theBackroomsV1;
import java.util.*;
//The Backrooms:
//written by Nicole Loughnane
//inspired by Zork and Kane Pixel's YouTube series
//2022

//play tested by: 
//TODO: get people to test the game!

public class MainGame {

	//class level variables are here:

	//has the game been won yet? leaving the backrooms is the only case where the game is won
	public static boolean gameWon;
	//has the player lost the game? there are 2 scenarios that will result in the player losing the game
	public static boolean gameLost;

	//this is the map of the game of type Room and a 2D array
	public static Room[][] map;
	//to navigate the map
	public static int row;
	public static int column;
	public static Room currentRoom;
	//declare the player's inventory of type InventoryItem
	public static ArrayList<Item> inventory;

	//create arraylists of items for rooms with multiple items
	public static ArrayList<Item> deadBodyRoom = new ArrayList<Item>();
	public static ArrayList<Item> cameraRoom = new ArrayList<Item>();
	public static ArrayList<Item> officeRoom = new ArrayList<Item>();
	public static ArrayList<Item> wallRoom = new ArrayList<Item>();

	//does the player have the VHS tape?
	public static boolean hasVHS = false;
	//has the player used the VHS tape
	public static boolean usedVHS = false;
	
	//game can randomly end lol
	public static Random r = new Random();

	//wowwwwww look how clean this main method is :)
	public static void main(String[] args) {
		runGame();
	}

	public static void runGame() {

		//the objects for the game are declared and constructed here

		//Tools and RoomItems - cosmetics or easter eggs
		Tool marker = new Tool("Marker", "A standard black marker. Nothing special.");
		RoomItem vcr = new RoomItem("VCR", "A standard VCR. Used to play and record VHS tapes.");
		Tool book = new Tool("Book", "\"The Yellow Wallpaper\" by Charlotte Perkins Gilman and published in 1892"
				+ " \nYou read this book in English class back in your first year of high school. "
				+ "\nIt tells the story of a woman's descent into psychosis after being trapped in a room on a supposed \"rest cure\" by her husband."
				+ "\nYou previously brushed off the book as a standard reading assignment but can now relate to her struggles...");
		Tool remote = new Tool("Remote", "A remote to turn on the TV and VCR");
		RoomItem backpack = new RoomItem("Backpack", "A green backpack with one zipper. The bag is a bit frayed and dirty. You open up the bag and find a screwdriver inside.");
		RoomItem body = new RoomItem("Body", "A dead body. It looks to be an older male wearing a hoodie. \nHe is covered in some sort of black fungus. You don't quite know what to make of it. You wonder what happened to him.");
		RoomItem camcorder = new RoomItem("Camcorder", "It’s a Panasonic Omnimovie Camcorder (a PV-520D to be exact).\nFrom your knowledge these can be quite finicky, but this one appears to be in working order. ");
		Tool vhs = new Tool("VHS Tape", "A common item for data storage. You wonder what it contains.\nA VCR should be able to reveal its contents.");
		RoomItem officeChair = new RoomItem("Chair", "A small black office chair");
		RoomItem desk = new RoomItem("Desk", "An office desk with one drawer for storage");
		RoomItem drawer = new RoomItem("Drawer", "You opened the drawer and an old, dusty book is inside");
		RoomItem vent = new RoomItem("Air Vent", "This air vent is secured with 4 screws in each corner. Once opened it might be large enough to crawl through.");
		RoomItem tv = new RoomItem("TV", "A TV screen that is plugged into the VCR. It can be turned on using the remote");
		RoomItem markings = new RoomItem("Markings", "The markings on the wall are a bit hard to read but you can make out the largest ones. \nThere are a pair of big, almost alien-like eyes drawn. Above those appears to be a drawing of a window to the outside world. \nMaybe the artist was missing home? \nThe next drawings are more disturbing. There are inked handprints on the wall, and next to those are the words \"DON'T MOVE. STAY STILL\" ...");

		//keys, necessary to win the game
		Key screwdriver = new Key("Screwdriver", "A standard screwdriver, but it's a bit rusty.", "Office Room");
		Key ladder = new Key("Ladder", "A small ladder useful for reaching high places.", "Dead Body Room");

		//add items to room lists
		deadBodyRoom.add(screwdriver);
		deadBodyRoom.add(backpack);
		deadBodyRoom.add(body);

		cameraRoom.add(camcorder);
		cameraRoom.add(vhs);

		officeRoom.add(book);
		officeRoom.add(vcr);
		officeRoom.add(remote);
		officeRoom.add(tv);
		officeRoom.add(vent);
		officeRoom.add(desk);
		officeRoom.add(officeChair);
		officeRoom.add(drawer);

		wallRoom.add(marker);
		wallRoom.add(markings);



		//stub out the map
		map = new Room[4][4];
		map[0][0] = new Room(false, true, true, false, "Starting Room", "You seem to be in an empty office room with ugly yellow wallpaper and you can hear the hum of fluorescent lights.\nYou're standing on a somewhat damp office carpet. How did you get here? Where did your friends go,\n or perhaps a more reasonable question, where did you go?\n");
		map[0][1] = new Room(false, false, true, true, "Wall Room", "This room appears to be just like the others but upon closer inspection you see some markings on the wall.\nA marker is lying on the ground next to the wall.\n", wallRoom);
		map[0][2] = new Room(false, false, true, false, "Tunnel Entrance Room", "A large empty room apart from a small entrance to a tunnel cut into the east wall.\nIt is too high to reach though. You will likely need a ladder of some kind to reach the tunnel.\n");
		map[0][3] = new Room(false, false, true, true, "Tunnel Room", "The tunnel leads to a room going south. There are dead ends to the east and north. You can also turn back the way you came from the west.\n");

		map[1][0] = new Room(true, true, false, false, "Ladder Room", "A medium sized room with nothing except a small ladder leaning up against the southern wall.\nYou can’t see any apparent reason for it being here or anything out of reach that would require it.\nMaybe you’ll find something in another room?\n", ladder);
		map[1][1] = new Room(true, true, true, true, "Vacant Room", "There is nothing special about this room in particular except that it has doorways leading in all directions.\nYou feel disoriented.\n");
		map[1][2] = new Room(true, false, false, true, "Camera Room", "A small room with a camera on a stand in the center of the room. Who could have placed this here?\nIt’s a Panasonic Omnimovie Camcorder. You’ve never seen one of these in person before: it’s quite large. \nIt’s turned off, maybe it’s finished recording? \nYou press eject on the camcorder and a VHS tape pops out.", cameraRoom);
		map[1][3] = new Room(true, false, false, false, "Dead Body Room", "As soon as you emerge from the tunnel you are overcome with a wave of fear.\nSitting in the corner of this room appears to be a dead body. A backpack is leaning up against the body.\nThe only way out is through the tunnel from which you came (north).\nAfter getting your bearings your eyes fixate back on the body, what happened here?\n", deadBodyRoom);

		map[2][0] = new Room(false, true, false, false, "Office Room", "This is a small room with an office chair and a desk with a drawer. There is also a TV monitor, VCR, and remote sitting on the desk and a large air vent in the southern corner. \nYou hear a whirring noise coming from that direction but it is inaccessible.\nThere is a remote off to the side for the unit. It looks like this workspace hasn’t been touched in awhile.\n", officeRoom);
		map[2][1] = new Room(true, true, false, true, "Noise Room", "At first glance, there is nothing special about this empty room, but you hear a voice coming from the room to the east.\n“Hello?” “Help me!” “Is anyone there?”\n");
		map[2][2] = new Room(false, false, false, true, "Entity Room", ""); //losing room
		map[2][3] = new Room();

		map[3][0] = new Room(false, false, false, false, "Gate Room", ""); //winning room

		//starting location of the player is in Starting Room [0,0]
		row = 0;
		column = 0;
		currentRoom = map[row][column];

		//initialize the players inventory
		inventory = new ArrayList<Item>();

		//game is not over
		gameWon = false;
		gameLost = false;


		/* Informational: Variables for the command, the command broken up, 
		 *  the scanner, and boolean for game over
		 */ 
		String userInput = "";
		String command = "";
		String item = "";
		Scanner s = new Scanner(System.in);

		//set to false when playing via the console, 
		//boolean done = false;

		/* Informational:  
		 *  get the intro to the game and print
		 */
		String output = gameIntro();
		System.out.println(output);

		/* Informational:  
		 * run the game until the game is won (true) or until the game is lost (true)
		 * otherwise the game will continue when it is not won AND it is not lost
		 */
		while(gameWon == false && gameLost == false){
			//every time a command is used, a new random number is generated
			int randomInt = r.nextInt(500) + 1;
			//Informational: get the user input
			System.out.print("\n\n>>");       //Informational: note this is for readability
			userInput = s.nextLine().toLowerCase();

			//Informational: get the command from the user input
			command = getFirstWord(userInput);

			//Informational: get the rest of the string after the first word if available

			item = getRestOfSentence(userInput);

			//Informational: use the command and item to determine the proper output

			output = executeCommand(command, item);

			//call to updateRoom() initializes room to correct row and column
			updateRoom();

			//Informational: print the output for the user
			System.out.println(output +"\n");

			//System.out.print("value of random: " + randomInt + "\n");

			//the player intentionally quitting results in the game being lost
			if(command.equals("quit")) {
				System.out.println("Game Over");
				gameLost = true;
			}

			//the player goes to the room with the monster and is killed, game ends
			if(row == 2 && column == 2) {
				System.out.println("You enter the room and look around for the source of the voice you just heard. \nA lengthy fungus-like figure is hunched in the corner. It is speaking in the same voice you overheard from the other room.\nYou say: “Hello?” It suddenly stands up and turns around.\nTowering and ungodly, it starts sprinting toward you. You tried to run away from it but couldn’t get away in time.\nYou feel your arm snap in half, you scream but you know for a fact that no one is there to hear you…\n");
				System.out.println("Game Over");
				gameLost = true;
			}

			//if the player goes to the room with the gate: the game is won!
			if(row == 3 && column == 0) {
				System.out.println("The air vent led you to this room. Initially, you feel discouraged, it appears to be empty.\nYou lean against a single barrier that lies in the room. Suddenly, you hear a loud whirring.\nYou hide behind the barrier. A flash of light sparks on the northern wall. It begins to spin in a circle faster and faster, opening a portal.\nTwo figures emerge, both wearing hazmat suits and carrying equipment of some kind.\nUnsure if they are friend or foe, you continue to hide. The figures climb into the air vent and disappear.\nNow alone you run to the portal as it must be the way out. Right?\nYou find yourself now in a dark laboratory. Are you back home, or in yet another dimension?\n");
				System.out.println("Game Won!");
				gameWon = true;
			}

			//randomInt used to determine random game loss: very small chance. Player noclips through the ground
			//sucks to suck
			if(randomInt <= 10) {
				System.out.println("You noclipped through the carpet but instead of being returned home, you feel yourself falling. You are now doomed to fall for all eternity.\n");
				System.out.println("Game Over");
				gameLost = true;
			}

		}
		s.close();

	}



	/**
	 * help method
	 * Method that returns all of the commands and what they do
	 * 
	 * example return output:
	 * "Command      Example      Description
	 *  take         take apple   used to pick up objects"
	 * 
	 * @return a String that contains all the command names, an example of use, and a description of what they do.
	 */
	public static String help(){
		return "The following commands are used to play the game\n"
				+ "=============================================================="
				+ "Command    Example      Description\n"
				+ "North      North        allows you to move North\n"
				+ "South      south        allows you to move South\n"
				+ "East       east         allows you to move East\n"
				+ "West       west         allows you to move West\n"
				+ "Look       Look         provides a detailed description of the room\n"
				+ "Take       take key     adds an item in a room to your inventory\n"
				+ "Drop       drop key     removes an item from your inventory and leaves it in the room\n"
				+ "Inventory  inventory    displays the names of items in your inventory\n"
				+ "Examine    examine key  provides a detailed description of the specified item\n"
				+ "Use        use key      allows you to use the item in your inventory\n"
				+ "Help       help         displays the help menu\n"
				+ "Quit       quit         player initiated end of game\n"
				+ "Tip: an item must be in your inventory to be able to use it";
	}

	/**
	 * north method
	 * 
	 * allows player to move North one space on the map only if there is an open passageway
	 * does not allow player to move North if there is no opening or if the player is at the end 
	 * of the map
	 * 
	 * @return a string that states you moved North if you move North, 
	 *         states you cannot move North if there is no opening
	 *       
	 */

	public static String north(){
		if(currentRoom.getCanGoNorth()){
			row-=1;
			updateRoom();
			System.out.println("You moved North: \n" + currentRoom.toString());
			return "";
		} else {
			return "You cannot move North.";
		}
	}



	/**
	 * south method
	 * 
	 * allows player to move South one space on the map only if there is an open passageway
	 * does not allow player to move South if there is no opening or if the player is at the end 
	 * of the map
	 * 
	 * @return a string that states you moved South if you move South, 
	 *         states you cannot move South if there is no opening
	 */
	public static String south(){
		if(currentRoom.getCanGoSouth()){
			row++;
			updateRoom();
			System.out.println("You moved South: \n" + currentRoom.toString());
			return "";
		} else {
			return "You cannot move South.";  
		}

	}

	/**
	 * east method
	 * 
	 * allows player to move East one space on the map only if there is an open passageway
	 * does not allow player to move East if there is no opening or if the player is at the end 
	 * of the map
	 * 
	 * @return a string that states you moved East if you move East, 
	 *         states you cannot move East if there is no opening
	 */
	public static String east(){
		if(currentRoom.getCanGoEast()){
			column++;
			updateRoom();
			System.out.println("You moved East: \n" + currentRoom.toString());
			return "";
		} else {
			return "You cannot move East.";
		}
	}

	/**
	 * west method
	 * 
	 * allows player to move West one space on the map only if there is an open passageway
	 * does not allow player to move West if there is no opening or if the player is at the end 
	 * of the map
	 * 
	 * @return a string that states you moved West if you move West, 
	 *         states you cannot move West if there is no opening
	 */
	public static String west(){
		if(currentRoom.getCanGoWest()){
			column--;
			updateRoom();
			System.out.println("You moved West: \n" + currentRoom.toString());
			return "";
		} else {
			return "You cannot move West.";   
		}

	}

	/**  
	 * updateRoom method
	 * Method to update the room you are in (currentRoom)
	 * this method uses the row and column values to 
	 * update the currentRoom location
	 * no parameters or return values
	 */
	public static void updateRoom() {
		currentRoom = map[row][column];
	}

	/**
	 * 	getCurrentRoom method
	 *  an accessor method that returns the currentRoom called getCurrentRoom
	 *  @return the current room, but update the room first
	 */

	public static Room getCurrentRoom(){
		updateRoom();
		return currentRoom;
	}


	/**
	 * quit Method
	 * Method that is involved with the termination of the game, it will be lost upon the player entering this command
	 * @return a game lost message
	 */
	public static String quit(){
		//gameLost
		return "The hum of the fluorescent lights and distant whirring become too much to bear.\n"
		+ "You give up hope for ever learning the backrooms and wander the endless halls, waiting for death.\n";
	}

	/**
	 * invalid method
	 * Method called when a player tries a command that is not used in the game
	 * @return message "I do not understand"
	 */
	public static String invalid(){
		return "I do not understand.";
	}

	public static String gameIntro() {
		String title = "\r\n"
				+ "▀▀█▀▀ █░░█ █▀▀ 　 ▒█▀▀█ █▀▀█ █▀▀ █░█ █▀▀█ █▀▀█ █▀▀█ █▀▄▀█ █▀▀ \r\n"
				+ "░▒█░░ █▀▀█ █▀▀ 　 ▒█▀▀▄ █▄▄█ █░░ █▀▄ █▄▄▀ █░░█ █░░█ █░▀░█ ▀▀█ \r\n"
				+ "░▒█░░ ▀░░▀ ▀▀▀ 　 ▒█▄▄█ ▀░░▀ ▀▀▀ ▀░▀ ▀░▀▀ ▀▀▀▀ ▀▀▀▀ ▀░░░▀ ▀▀▀\n"
				+ "============================================================================================================================\n\n";
		String intro = "The year is 1989. You're in your senior year of high school, hoping to study film in university once you graduate,\nbut you still haven't decided where you're going to attend.\n"
				+ "A bell rings.\n"
				+ "You snap out of your post graduation thoughts and find yourself sitting in your pre-calculus class. The teacher has just dismissed you all for the day\nso you hastily pack up your things. You wouldn't want to miss your meeting with the film club. You head out the door and make your way to the parking lot.\n"
				+ "You walk past a missing person sign hanging on the bulletin board that you hadn't noticed earlier. Missing person reports have been increasing lately.\nEven one of your classmates has gone missing. Every trail the police have followed has led to a dead end.\nIt's almost as if these people have vanished out of thin air.\n"
				+ "Granted, you do live in San Francisco, anything can happen here. It was just after the earthquake a month ago that these reports started flooding in across the news.\nThe earthquake hit Loma Prieta, it rocked your house pretty badly but thankfully no one was hurt. "
				+ "You unlock your car, open the door, and head inside.\n"
				+ "Your film club is going to start filming a new project today and you're providing the camera. You start your car and head to the park.\n"
				;
		String filmShoot = "“Hey Max!” your friend Dustin announced, as you are walking up to the meeting. “Ready to get started?”\n"
				+ "You're feeling a bit strange, perhaps it's from that missing person sign you saw earlier, you try your best to put it in the back of your mind.\n"
				+ "You hear Dustin say, \"Action!\" so you start the tape, but suddenly you feel yourself falling almost as if you were in a dream.\nYou can't see anything for a second but, suddenly, hit the ground. Or is this the ground? Where are you?"
				+ "\r\n"
				+ "You stand up, still holding your film camera, shakily though. You seem to be in an empty office room with ugly yellow wallpaper\nand you can hear the hum of fluorescent lights overhead. You're standing on a somewhat damp office carpet.\n"
				+ "Despite this great filming opportunity that the universe has now granted you with, you start to feel anxious.\n"
				+ "Your mind starts to drift to the missing person reports, is this where everyone has gone?\n";
		String tip = "============================================================================================================================\n"
				+ "Tip: This game was inspired by the classic 80s video game series: Zork and therefore, operates in a similar fashion\n"
				+ "Type \"help\" for help\n";
		return title + intro + filmShoot + tip;
	}

	/**
	 * getFirstWord method
	 * pulls the first word out of any phrase (1 or more words)
	 * @param a string that contains the commands from the user
	 * @return a string that is only the first word, 
	 *         returns a blank string "" if nothing entered, 
	 */
	public static String getFirstWord(String input){
		int spaceLocation = input.indexOf(" ");
		if(spaceLocation > 0)
			return input.substring(0,spaceLocation);
		if(input.length() >0)
			return input;
		return "";
	}

	/**
	 * getRestOfSentence 
	 * pulls everything after the first word and the space behind it
	 * @param a string that contains the commands from the user
	 * @return a string that returns everything after the first word 
	 *         and the space behind it, returns a blank string "" if 1 word entry 
	 *         or nothing entered. 
	 */	
	public static String getRestOfSentence(String input){
		int spaceLocation = input.indexOf(" ");
		if(spaceLocation >= 0)
			return input.substring(spaceLocation+1);
		return "";
	}	

	/**
	 * take method
	 * Method to allow you to take an item
	 * "You took the <itemName>." 
	 * 
	 * example return statement:
	 * "You took the apple." 
	 * 
	 * @param takes in a String to determine what object was picked up
	 * @return a String that states "You took the <itemName>"
	 */


	public static String take(String item){
		String result = "";
		//System.out.println("hasObject call: "+currentRoom.hasObject(item));
		if(currentRoom.hasObject(item) == false) {
			result = "The object is not in this room so you cannot take it";
			//a RoomItem cannot be picked up by the player
			//explanations are given to help the player
		}else if(item.toLowerCase().equals("body") && getCurrentRoom().getName().equalsIgnoreCase("Dead Body Room")) {
			result = "You can't take a dead body!!!";
		}else if(item.toLowerCase().equals("backpack") && getCurrentRoom().getName().equalsIgnoreCase("Dead Body Room")) {
			result = "You are already wearing a backpack so you don't need another one";
		}
		else if(item.toLowerCase().equals("camcorder") && getCurrentRoom().getName().equalsIgnoreCase("Camera Room")) {
			result = "You are already using a camera. No need for another one.";
		}
		else if(currentRoom.findObject(item) instanceof RoomItem && currentRoom.findObject(item) != null ) {
			result = "You cannot take this item";
		} 
		else {
			result = "You took the " + item +".";
			Item i = currentRoom.removeObject(item);
			//check if the item picked up was a vhs tape
			if(item.toLowerCase().equals("vhs tape")) {
				hasVHS = true;
			}
			inventory.add(i);
		}
		return result;
	}

	/** 
	 * drop method
	 * Method to allow you to drop an item
	 * "You dropped the <itemName>." 
	 * 
	 * example return statement:
	 * "You dropped the apple."
	 * 
	 * @param takes in a string to determine what object was dropped
	 * @return a string that states "You dropped the <itemName>"
	 */

	public static String drop(String objectName){
		String result = "You cannot drop the object because it is not in your inventory.";
		for(int i = 0; i < inventory.size(); i++) {
			if(inventory.get(i).getName().toLowerCase().equals(objectName.toLowerCase())) {
				result = "You dropped the " + objectName +".";
				currentRoom.addObject(inventory.get(i));
				inventory.remove(i);

			} 
		}
		return result; 


	}
	/** 
	 * look method
	 * Method to allow you to look around the room
	 *  @return a string of the room description and items in the room
	 */	

	public static String look(){
		return currentRoom.toString() /*+ "\n" + currentRoom.getNamesOfObjectsInRoom() */;
	}

	/** 
	 * inventory method
	 * Method to display the items in your inventory
	 * "The current items in your inventory are:"
	 *  @return the "The current items in your inventory are: ....",
	 *  or
	 *  @return "there are no items in your inventory" 
	 */

	public static String inventory(){
		String items = "";

		if(inventory.size() == 0) {
			//no items have been picked up yet
			return "There are no items in your inventory";
		} else {
			//there is at least one item in the players inventory
			for(int i = 0; i < inventory.size(); i++) {
				items += inventory.get(i) + "\n"; 
			}
			return "The current item in your inventory are: " + items;  
		}

	}	

	/**
	 * examine method
	 * Method that returns the description of an item that is in the inventory or in the room
	 * 
	 * @param takes in a string to determine what item you want the description of
	 * @return a string that is the full description of the item
	 */

	public static String examine(String item){
		String result = "";

		//check if the item was found in the room
		if(currentRoom.hasObject(item) == false) {
			result = "The object is not in this room or in your inventory so you cannot examine it";
		} else {
			//the item is in the room
			//return description: call getRoomObjectDesc
			result = /*"Description of the " + item + ": " + */getRoomObjectDesc(item);
		}

		//check if the item was found in the inventory
		for(int i = 0; i < inventory.size(); i++) {
			if(inventory.get(i).getName().toLowerCase().equals(item.toLowerCase())) {
				//return description of the item in the inventory
				result = /*"Description of the " + item + ": " + */inventory.get(i).getDescription();
			} 
		}

		return result;
	}

	/**
	 * getRoomObjectDesc method
	 * Method that retrieves the description of an item and passes it to the examine method
	 * the findObject method is utilized to get the description 
	 * 
	 * @param takes in a string to determine what item you want the description of
	 * @return a string that is the description of the item
	 */

	public static String getRoomObjectDesc(String objectName) {
		String objectDesc = "";
		if(currentRoom.findObject(objectName) != null) {
			objectDesc = currentRoom.findObject(objectName).getDescription();
		}
		return objectDesc;
	}



	/**  
	 * use method
	 * Method that allows you to use an item
	 * The player will only be allowed to use an item in their inventory, and in the correct room
	 * Also allows for an item of type Key to be used to unlock obstacles
	 * RoomItems or Tools can be used through this method
	 * 
	 * @param takes in a string to determine what item you want to use
	 * @return a string that You used the item, do not use print or println
	 */

	/* 
	 * a Key opens the access of a specific Room
	 * if the player is in the Room that the "door" should be opened and has the key 
	 * to open the door, then update the Room to allow the player to move into and out 
	 * of the room
	 * If the player is not in the correct Room, state that the key will not work here
	 * If the item noted by the player cannot be used ever, then state that the player cannot use that item
	 * If the player does not have the item, state that the player does not have the item.
	 */
	public static String use(String item) {
		String result = "You cannot use this item";
		if(item.toLowerCase().equals("vcr")) {
			//this has the same effect as using the VHS tape it depends on if the player wants to say "use vhs tape" or "use vcr"
			if(getCurrentRoom().getName().equalsIgnoreCase("Office Room") && hasVHS) {
				usedVHS = true;
				System.out.println("VHS tape has been used: " + usedVHS);
				System.out.println("VCR has been used");
				result = "You pop the VHS tape inside the VCR. It is powered off though.";
			} else {
				System.out.println("VHS tape has been used: " + usedVHS);
				System.out.println("player has the vhs tape:" + hasVHS);
				result = "You cannot use this item without a VHS tape";
			}
		}
		for(int i = 0; i < inventory.size(); i++) {
			//if an item in the inventory item matches the name of the user inputted item
			if(inventory.get(i).getName().toLowerCase().equals(item.toLowerCase())) {
				//KEYS:
				//if the player uses the ladder
				if(item.toLowerCase().equals("ladder")) {
					//if the room is the tunnel entrance
					if(getCurrentRoom().getName().equalsIgnoreCase("Tunnel Entrance Room")) {
						//can go east = true instead of false, player can access tunnel
						map[0][2].setCanGoEast(true);
						//update description
						map[0][2].setDescription("A large empty room apart from a small entrance to a tunnel cut into the east wall.\nIt was too high to reach until you placed a ladder down. Move east to enter the tunnel. \n");
						result = "You used the ladder and can now reach high enough to enter the tunnel to the east.";
					} else {
						result = "There is no apparent reason to use a ladder in this room.";
					}

				} else if(item.toLowerCase().equals("screwdriver")) {
					//if the room is the office room with the air duct  
					if(getCurrentRoom().getName().equalsIgnoreCase("Office Room")) {
						//can go south - true instead of false, player can access the gate
						map[2][0].setCanGoSouth(true);
						map[2][0].setDescription("This is a small room with an office chair, a desk with a drawer, TV monitor, VCR, and a large air vent in the southern corner. \nYou hear a whirring noise coming from that direction and is now accessible via the air vent.\nThere is a remote off to the side for the unit. It looks like this workspace hasn’t been touched in awhile.");
						result = "You used the screwdriver to open the airduct. The vent pops off and you can fit inside to go south, if you get on your hands and knees.";

					} else {
						result = "There is no apparent use for a screwdriver in this room";
					}
				}
				//TOOLS:
				else if(item.toLowerCase().equals("marker")) {
					result = "You cannot find a good use for this marker";

					//EASTER EGG: the player plays the VHS tape in the VCR
				} else if(item.toLowerCase().equals("vhs tape")) {
					if(getCurrentRoom().getName().equalsIgnoreCase("Office Room")) {
						usedVHS = true;
						result = "You pop the VHS tape inside the VCR. It is powered off though.";
					} else {
						result = "You cannot use the VHS tape in this room";
					}

				} else if(item.toLowerCase().equals("remote")) {

					if(getCurrentRoom().getName().equalsIgnoreCase("Office Room") && usedVHS) {
						result = "You use the remote to turn on the TV and VCR. \n"
								+ "The TV turns on and starts loading the tape. You are presented with a series of clips that appear to cut from one to the next \n"
								+ "dependent upon when the camcorder detected motion. The first clip is dated March 5 of 1989 at 19:39:43.\n"
								+ "You see 3 people in yellow hazmat suits walking down a hallway in the distance. Their yellow suits match the ugly yellow wallpaper. \n"
								+ "You wonder to yourself \"Is this place toxic?\" \"How did those people get here?\" \n"
								+ "The next clip rolls this time at 20:26:43. More suited people. \n"
								+ "Another clip at 21:14:04. This time it is a loud noise. It sounds similar to the noise you currently hear in the southern direction. \n"
								+ "2:13:35. Another noise but this time it sounds like buzzing. You think it might be the microphone failing on the camcorder. \n"
								+ "Last clip at 3:53:42. Motion detected again. At first you don't see anything. \n"
								+ "But in the distance you start to notice a lengthy, black figure. It is peering around the corner. The screen turns white and you are now presented with a logo. \n"
								+ "It says \"Async\" \n"
								+ "The tape clicks off. \n";
					} else if(hasVHS == false){
						result = "You use the remote but are presented with a black screen."
								+ "\nTry putting in a VHS tape and using the remote again.";
					} else {
						result = "You cannot use the remote in this room";
					}

				}

			} 
		} 

		return result;
	}

	/**
	 * executeCommand method
	 * This method uses the first word to call the appropriate method that you
	 * made above. It manages complexity by hosting the 
	 * logic to determine which method should be used.
	 * (for example, if the command is north, call the north() method). 
	 * @param the String command used to check which method to call
	 * @param the String item used for methods that interact with objects 
	 * @return a String that is passed back from the appropriate method, 
	 *         
	 */
	public static String executeCommand(String command, String item){
		if(command.equals("north"))
			return north();
		if(command.equals("south"))
			return south();
		if(command.equals("east"))
			return east();
		if(command.equals("west"))
			return west();
		if(command.equals("inventory"))
			return inventory();
		if(command.equals("look"))
			return look();
		if(command.equals("take"))
			return take(item);
		if(command.equals("drop"))
			return drop(item);
		if(command.equals("examine"))
			return examine(item);
		if(command.equals("use"))
			return use(item);
		if(command.equals("help"))
			return help();
		if(command.equals("quit"))
			return quit();
		return invalid();

	}
	//Leaving this in, just in case. this was in getRoomObjectDesc and has since been replaced with more efficient and reusable code
	/*
	String getObjectDesc = "";
	//iterate through the list of objects in the room to find the matching one
	//find what room the player is in
	if(currentRoom.getName().equals("Dead Body Room")) {
		for(int i = 0; i < deadBodyRoom.size(); i++) {
			//if the item name in this room matches objectName, return description
			if(deadBodyRoom.get(i).getName().toLowerCase().equals(objectName.toLowerCase())) {
				getObjectDesc = deadBodyRoom.get(i).getDescription();
			}
		}
	} else if(currentRoom.getName().equals("Camera Room")) {
		for(int i = 0; i < cameraRoom.size(); i++) {
			//if the item name in this room matches objectName, return description
			//System.out.println("inside getRoomObjectDesc and room is camera room");
			if(cameraRoom.get(i).getName().toLowerCase().equals(objectName.toLowerCase())) {
				//System.out.println("inside getRoomObjectDesc and room is camera room, getting description of matching item");
				getObjectDesc = cameraRoom.get(i).getDescription();
			}
		}
	} else if (currentRoom.getName().equals("Ladder Room")) {
		getObjectDesc = ladder.getDescription();
	} else if (currentRoom.getName().equals("Wall Room")) {
		//last room 
		getObjectDesc = marker.getDescription();
	}
	return getObjectDesc;
	 */
}
