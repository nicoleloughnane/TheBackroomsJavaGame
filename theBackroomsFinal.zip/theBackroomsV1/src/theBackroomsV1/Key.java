package theBackroomsV1;

public class Key implements Item {
	
	/*
	Create 3 instance variables:  name, description, and name of the room that the key works in
	*/
	private String name;
	private String description;
	private String room;


	/**
	 * Key class constructor
	 * it builds a key with a name, description, and room
	 * @param: a string to set the name of a Key object
	 * @param: a string to set the description of a Key object
	 * @param: a string to set the room of a Key object
	 */
	
	public Key(String n, String d, String r) {
		name = n;
		description = d;
		room = r;
	}


	
	/**
	 * Mutator method called "setName"
	 * 	This method is used to change the name of a Key object
	 * 	@param: a String to update the name of a Key object
	*/

	public void setName(String n) {
		name = n;
	}



	
	/**
	 * 	Mutator method called "setDescription"
	 * 	This method is used to change the description of a Key object
	 * 	@param: a String to update the description of a Key object
	*/

	public void setDescription(String d) {
		description = d;
	}
	
	/**
	 * Accessor method called "getName"
	 * This method is used to retrieve the name of a Key object
	 * @return: a String that is the name of a Key object
	*/

	public String getName() {
		return name;
	}



	/**
	 * Accessor method called "getDescription"
	 * This method is used to retrieve the description of a Key object
	 * @return: a String that is the description of a Key object
	*/	

	public String getDescription() {
		return description;
	}


/**
	 * Accessor method called "getRoomIWorkIn"
	 * This method is used to retrieve the name of the room the key works in
	 * @return: a String that is the name of the room the key works in
	*/	

	public String getRoomIWorkIn() {
		return room;
	}

	
	/**
	 * Accessor method called "toString", overwrites the default toString method
	 * This method is used to retrieve all of the characteristics of a Key object
	 * @return: a String that is all of the characteristics of a Key object
	*/		
	
	public String toString() {
		return "\n" + name + ":\nDescription: " + description;
	}



}
