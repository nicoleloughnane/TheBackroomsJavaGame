package theBackroomsV1;

public class RoomItem implements Item{

	//NOTE: RoomItems cannot be taken/picked up by the player
	/*
	Create 2 instance variables:  name, description
	*/
	private String name;
	private String description;


	/**
	 * RoomItem class constructor
	 * it builds a key with a name, description
	 * @param: a string to set the name of a RoomItem object
	 * @param: a string to set the description of a RoomItem object
	 */
	
	public RoomItem(String n, String d) {
		name = n;
		description = d;
	}


	
	/**
	 * Mutator method called "setName"
	 * 	This method is used to change the name of a RoomItem object
	 * 	@param: a String to update the name of a RoomItem object
	*/

	public void setName(String n) {
		name = n;
	}

	
	/**
	 * 	Mutator method called "setDescription"
	 * 	This method is used to change the description of a RoomItem object
	 * 	@param: a String to update the description of a RoomItem object
	*/

	public void setDescription(String d) {
		description = d;
	}
	
	/**
	 * Accessor method called "getName"
	 * This method is used to retrieve the name of a RoomItem object
	 * @return: a String that is the name of a RoomItem object
	*/

	public String getName() {
		return name;
	}



	/**
	 * Accessor method called "getDescription"
	 * This method is used to retrieve the description of a RoomItem object
	 * @return: a String that is the description of a RoomItem object
	*/	

	public String getDescription() {
		return description;
	}

	
	
	public String toString() {
		return "\n" + name + ":\nDescription: " + description;
	}
}
