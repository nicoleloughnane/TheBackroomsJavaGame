package theBackroomsV1;

import java.util.*;

/**
 * Room Class
 * Each room represents a spot in the world
 * Room's have names, descriptions, inventories, and 
 * passages or lack there of to the N,S,E, and W
 */

public class Room {

	//fields for the room class, t/f if player can move directions
	//description and name of the room

	private boolean canGoNorth;
	private boolean canGoSouth;
	private boolean canGoEast;
	private boolean canGoWest;
	private String description;
	private String name;


	// Instance variable that gives the Room an inventory
	// This is an ArrayList that only the Room can access
	// This is of type InventoryItem

	private ArrayList<Item> inventory;

	/**
	 * default Room constructor
	 * it populates all of the instance variables with default values of false for movement
	 * it also adds a description that this is not actually a room
	 */
	public Room(){
		this.canGoNorth = false;
		this.canGoSouth = false;
		this.canGoEast = false;
		this.canGoWest = false;
		this.name = "Not a room";
		this.description = "This is not a room, you shouldn't be here!!!";
	}

	/**
	 * custom Room constructor 
	 * use to build an instance of a Room object 
	 * the client populates all of the instance variables by
	 * passing the following parameters in this order
	 * 
	 * @param canGoNorth
	 * @param canGoSouth
	 * @param canGoEast
	 * @param canGoWest
	 * @param name
	 * @param description
	 */
	public Room(boolean canGoNorth, boolean canGoEast, boolean canGoSouth, boolean canGoWest, String name, String description){
		this.canGoNorth = canGoNorth;
		this.canGoEast = canGoEast;
		this.canGoSouth = canGoSouth;
		this.canGoWest = canGoWest;
		this.name = name;
		this.description = description;

		//initialize the inventory ArrayList
		inventory = new ArrayList<Item>();

	}

	/**
	 * custom Room constructor with 7 parameters 
	 * use to build an instance of a Room object 
	 * the client populates all of the instance variables by
	 * passing the following parameters in this order
	 * 
	 * @param canGoNorth
	 * @param canGoSouth
	 * @param canGoEast
	 * @param canGoWest
	 * @param name
	 * @param description
	 * @param item  -- this is type Inventory
	 */

	public Room(boolean canGoNorth, boolean canGoEast, boolean canGoSouth, boolean canGoWest, String name, String description, Item item) {
		this.canGoNorth = canGoNorth;
		this.canGoSouth = canGoSouth;
		this.canGoEast = canGoEast;
		this.canGoWest = canGoWest;
		this.name = name;
		this.description = description;

		inventory = new ArrayList<Item>();
		inventory.add(item);


	}  

	/**
	 * custom Room constructor with 7 parameters 
	 * use to build an instance of a Room object 
	 * the client populates all of the instance variables by
	 * passing the following parameters in this order
	 * 
	 * @param canGoNorth
	 * @param canGoSouth
	 * @param canGoEast
	 * @param canGoWest
	 * @param name
	 * @param description
	 * @param item  -- this is an ArrayList of type Inventory
	 */

	 public Room(boolean canGoNorth, boolean canGoEast, boolean canGoSouth, boolean canGoWest, String name, String description, ArrayList<Item> items) {
		this.canGoNorth = canGoNorth;
		this.canGoSouth = canGoSouth;
		this.canGoEast = canGoEast;
		this.canGoWest = canGoWest;
		this.name = name;
		this.description = description;

		inventory = items;


	} 
	

	/**
	 * getDescription accessor method
	 * gets the room description
	 * @return the description
	 */

	public String getDescription(){
		return this.description;
	}

	/**
	 * getName accessor method
	 * It gets the room name
	 * @return the name
	 */

	public String getName(){
		return this.name;
	}

	/**
	 * setDescription mutator method
	 * It sets the room description
	 * @param d is the description of the room
	 */

	public void setDescription(String d){
		description = d;
	}

	/**
	 * setName mutator method
	 * It sets the room name
	 * @param n is the name you want the room to have
	 */

	public void setName(String n){
		name = n;
	}


	/**
	 * getCanGoNorth accessor method
	 * used to determine if the player can move North
	 * @return the value of canGoNorth
	 */

	public boolean getCanGoNorth(){
		return this.canGoNorth;
	}

	/**
	 * getCanGoSouth accessor method
	 * used to determine if the player can move South
	 * @return the value of canGoSouth
	 */

	public boolean getCanGoSouth(){
		return this.canGoSouth;
	}

	/**
	 * getCanGoEast accessor method
	 * used to determine if the player can move East
	 * @return the value of canGoEast
	 */

	public boolean getCanGoEast(){
		return this.canGoEast;
	}

	/**
	 * getCanGoWest accessor method
	 * used to determine if the player can move West
	 * @return the value of canGoWest
	 */

	public boolean getCanGoWest(){
		return this.canGoWest;
	}

	/**
	 * setCanGoNorth mutator method
	 * used to update if the player can move North
	 * @param a value to change the canGoNorth field
	 */

	public void setCanGoNorth(boolean b){
		this.canGoNorth = b;

	}

	/**
	 * setCanGoSouth mutator method
	 * used to update if the player can move South
	 * @param a value to change the canGoSouth field
	 */

	public void setCanGoSouth(boolean b){
		this.canGoSouth = b;

	}


	/**
	 * setCanGoEast mutator method
	 * used to update if the player can move East
	 * @param a value to change the canGoEast field
	 */

	public void setCanGoEast(boolean b){
		this.canGoEast = b;

	}



	/**
	 * setCanGoWest mutator method
	 * used to update if the player can move West
	 * @param a value to change the canGoWest field
	 */

	public void setCanGoWest(boolean b){
		this.canGoWest = b;		
	}

	/**
	 * toString accessor method
	 * used to retrieve the state of the room you are in
	 * 
	 * example output: 
	 * Kitchen 
	 * A room with a table and fridge  
	 * GoNorth: True GoSouth:False GoEast: True GoWest: True
	 * 
	 * @return a String with the Room Name, Description, (and the ability to move each direction)
	 */
		public String toString(){
			return name 
					+ "\n=================================================================================\n" 
					+ description /*+ "\nCan go North: " + canGoNorth + " Can go South: " + canGoSouth + " Can go East: " + canGoEast + " Can go West: " +canGoWest */;
		}
		

/**
 * hasObject accessor method
 * uses a String to search through the objects in the Room (room's inventory) to 
 * determine if the object is present
 * 
 * @param objectName - a String that is the name of the object
 * @return a boolean that is true if the object is in the Room
 *         and false if it is not
 */

	public boolean hasObject(String objectName) {
		boolean objectInRoom = false;
		for (int i = 0; i < inventory.size(); i++) {
			if (inventory.get(i).getName().toLowerCase().equals(objectName.toLowerCase())) {
				objectInRoom = true;
			}
		}
		return objectInRoom;
	} 
 
	/**
	 * findObject accessor method
	 * uses a String to search through the objects in the Room (room's inventory) to 
	 * determine if the object is present
	 * if it is: determine the type of the item and return the found object
	 * 
	 * @param objectName - a String that is the name of the object
	 * @return an Item that is assigned a value if the object is in the Room
	 *         a null if it is not in the Room
	 */
	public Item findObject(String objectName) {
		Item foundObject = null;
		for (int i = 0; i < inventory.size(); i++) {
			//if the item is in the room
			if (inventory.get(i).getName().toLowerCase().equals(objectName.toLowerCase())) {
				//item is in the room, determine the type
				if(inventory.get(i) instanceof Key) {
					//System.out.println("This is a key");
					foundObject = (Key)inventory.get(i);
				} else if(inventory.get(i) instanceof RoomItem){
					//System.out.println("This is a roomitem");
					foundObject = (RoomItem)inventory.get(i);
				} else {
					//System.out.println("This is a tool");
					foundObject = (Tool)inventory.get(i);
				}
			}
		}
		//remember to check if the item is null or not
		return foundObject;
	}
 
 
/**
 * addObject mutator method
 * used to pass an Object to the room 
 * 
 * @param invObject - a Inventory object to be added to the room inventory
 */

	public void addObject(Item invObject) {
		inventory.add(invObject);
	} 
	
	
	
	
	
/**
 * removeObject mutator method
 * used to remove an Object from the room and
 * pass it to the client code 
 * 
 * @param objName - a String that is the name of the object to pull from the room
 * @return an Inventory object that is the object to be pulled from the room
 * 
 */

	public Item removeObject(String objName) {
		Item objectToRemove = null;
		for (int i = 0; i < inventory.size(); i++) {
			if(inventory.get(i).getName().toLowerCase().equals(objName.toLowerCase())) {
				objectToRemove = inventory.remove(i);
			} 
		}
		return objectToRemove;
	} 


	
	
	
	
	

/**
 * getNamesOfObjectsInRoom accessor method
 * used to get the names of all of the Objects in the Room Inventory
 * This is used for testing purposes and is not currently being used in the game
 * 
 * @return returns "Items in room are : " followed by the items in the room. 
 *         If not items are in the room, then return "No items are in the room"
 *         return statement is formatted for if there is just one item in the room or multiple
 */
	
	public String getNamesOfObjectsInRoom() {
		String items = "";
		if(inventory.size() == 0) {
			return "No items are in the room";
		} else if (inventory.size() == 1){
			for(int i = 0; i < inventory.size(); i++) {
				items += inventory.get(i).getName();
			}
			return "Item in the room is: " + items;
		} else {
			for(int i = 0; i < inventory.size(); i++) {
				items += inventory.get(i).getName() + ", ";
			}
			return "Items in the room are: " + items;
		}
	
	} 





}
