package theBackroomsV1;
/**
 * This is an Interface called "Item".  
 * It allows objects that meet the following criteria to be included in
 * an Item Type object:
 * the object must be able to get its name and description.
 * 
 * Key, Tool, and RoomItem use this interface
 */
 
 
public interface Item {

	String getName();
	String getDescription();
	
}
